# Tetris
Tetris game written in HTML5 + CSS3 + jQuery. This WebApp is a "Responsive Web Design" (RWD) website. 


<a href="https://tetris-90067.firebaseapp.com">Play game</a>
